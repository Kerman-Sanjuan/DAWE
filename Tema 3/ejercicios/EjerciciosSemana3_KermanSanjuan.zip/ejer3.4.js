var contador = {
  cont: 0,
  sig: function () {
    this.cont++;
    console.log(this.cont);
  },
};
